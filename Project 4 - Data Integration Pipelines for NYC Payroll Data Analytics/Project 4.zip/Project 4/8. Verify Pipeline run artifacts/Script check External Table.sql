SELECT TOP (100) [AgencyName]
,[FiscalYear]
,[TotalPaid]
 FROM [dbo].[NYC_Payroll_Summary]